import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HiddenFormFieldsServlet")
public class HiddenFormFieldsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String sessionId = request.getParameter("session_id");

        if (sessionId == null || sessionId.isEmpty()) {
            sessionId = "12345";
        }

        response.setContentType("text/html");
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session Tracking using Hidden Form Fields</h1>");
        response.getWriter().println("<form method='post' action='HiddenFormFieldsServlet'>");
        response.getWriter().println("Session ID: <input type='hidden' name='session_id' value='" + sessionId + "'>");
        response.getWriter().println("<input type='submit' value='Refresh'>");
        response.getWriter().println("</form>");
        response.getWriter().println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
