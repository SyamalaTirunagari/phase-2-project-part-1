import java.io.IOException;
import javax.servlet.*;

public class MyServlet implements Servlet {
    private ServletConfig config;

    public void init(ServletConfig config) throws ServletException {
        this.config = config;
    }

    public void service(ServletRequest req, ServletResponse res)
            throws ServletException, IOException {
        res.setContentType("text/html");
        res.getWriter().println("<html><body>");
        res.getWriter().println("<h1>Hello from MyServlet</h1>");
        res.getWriter().println("</body></html>");
    }

    public void destroy() {
    }

    public ServletConfig getServletConfig() {
        return config;
    }

	@Override
	public String getServletInfo() {
		// TODO Auto-generated method stub
		return null;
	}
}


