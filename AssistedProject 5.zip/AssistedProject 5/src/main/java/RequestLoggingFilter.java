import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class RequestLoggingFilter implements Filter {
    public void init(FilterConfig config) throws ServletException {
        // Initialization code, if needed
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Log the incoming request
        System.out.println("Request received from " + request.getRemoteAddr());

        // Pass the request/response through the filter chain
        chain.doFilter(request, response);

        // Log the response
        System.out.println("Response sent to " + request.getRemoteAddr());
    }

    public void destroy() {
        // Cleanup code, if needed
    }
}
