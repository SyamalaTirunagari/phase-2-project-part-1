import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SessionTrackingServlet")
public class SessionTrackingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve or create a session cookie
        Cookie[] cookies = request.getCookies();
        Cookie sessionCookie = findCookie(cookies, "session_id");

        if (sessionCookie == null) {
            // If the session cookie does not exist, create one
            sessionCookie = new Cookie("session_id", "12345");
            sessionCookie.setMaxAge(3600); // 1 hour (in seconds)
            response.addCookie(sessionCookie);
        }

        response.setContentType("text/html");
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session Tracking using Cookies</h1>");
        response.getWriter().println("<p>Session ID: " + sessionCookie.getValue() + "</p>");
        response.getWriter().println("</body></html>");
    }

    private Cookie findCookie(Cookie[] cookies, String name) {
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name)) {
                    return cookie;
                }
            }
        }
        return null;
    }
}
