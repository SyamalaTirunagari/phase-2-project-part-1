import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/URLRewriteServlet")
public class URLRewriteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String sessionId = request.getParameter("session_id");

        if (sessionId == null || sessionId.isEmpty()) {
            sessionId = "12345";
        }

        response.setContentType("text/html");
        response.getWriter().println("<html><body>");
        response.getWriter().println("<h1>Session Tracking using URL Rewrite</h1>");
        response.getWriter().println("<p>Session ID: " + sessionId + "</p>");
        response.getWriter().println("<a href='URLRewriteServlet?session_id=" + sessionId + "'>Refresh</a>");
        response.getWriter().println("</body></html>");
    }
}

